/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#ifndef ZEBRA_H
#define ZEBRA_H

#include "Hayvan.h"

class Zebra : public Hayvan {
public:
    Zebra(const std::string& ad, int yas);
    void Beslen() override;
};

#endif
