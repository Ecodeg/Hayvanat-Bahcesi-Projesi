/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#include <iostream>
#include <algorithm>
#include <locale.h> //setlocale 
#include "Hayvan.h"
#include "Aslan.h"
#include "Zebra.h"
#include "Kartal.h"
#include "HayvanatBahcesi.h"



int main() {

    setlocale(LC_ALL, "Turkish"); //T�rk�e karakterler i�in

    HayvanatBahcesi hayvanatBahcesi;

    while (true) {  //Kullan�c� Aray�z�
        std::cout << std::endl;
        std::cout << "----- Hayvanat Bah�esi Y�netimi -----" << std::endl;
        std::cout << "1. Hayvan Ekle" << std::endl;
        std::cout << "2. Hayvanlar� G�ster" << std::endl;
        std::cout << "3. Hayvan D�zenle" << std::endl;
        std::cout << "4. Hayvanlar� Besle" << std::endl;
        std::cout << "5. Rapor Olu�tur" << std::endl;
        std::cout << "6. C�k��" << std::endl;
        std::cout << "Se�iminizi yap�n: ";

        int secim;
        std::cin >> secim;
        std::cout << std::endl;

        if (std::cin.fail()) {  //Ge�ersiz bir de�er girdi�i zaman ekrana bas�lacak uyar�
            std::cout << "Ge�ersiz se�im! L�tfen bir say� girin." << std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }

        switch (secim) {
        case 1: {  //Hayvan Ekle
            std::cout << "Hayvan t�r�n� girin (Aslan/Zebra/Kartal): ";
            std::string tur;
            std::cin >> tur;

            // Hata vermemesi i�in hayvan t�r�n� b�y�k harfe d�n��t�r�r
            std::transform(tur.begin(), tur.end(), tur.begin(), ::toupper);

            std::cout << "Hayvan ad�n� girin: ";
            std::string ad;
            std::cin >> ad;

            std::cout << "Hayvan ya��n� girin: ";
            int yas;
            std::cin >> yas;

            Hayvan* hayvan = nullptr;

            if (tur == "ASLAN") {
                hayvan = new Aslan(ad, yas);
            }
            else if (tur == "ZEBRA") {
                hayvan = new Zebra(ad, yas);
            }
            else if (tur == "KARTAL") {
                hayvan = new Kartal(ad, yas);
            }
            else {
                std::cout << "Ge�ersiz hayvan t�r�! L�tfen Aslan, Zebra veya Kartal girin." << std::endl;
                break;
            }

            hayvanatBahcesi.HayvanEkle(hayvan);
            std::cout << "Hayvan ba�ar�yla eklendi!" << std::endl;
            break;
        }


        case 2: {  //Hayvanlar� G�ster
            hayvanatBahcesi.HayvanlariGoster();
            break;
        }
        case 3: {  //Hayvan D�zenle
            std::cout << "D�zenlemek istedi�iniz hayvan�n indeksini girin: ";
            int index;
            std::cin >> index;

            hayvanatBahcesi.HayvanDuzenle(index-1); //index-1 yapt�k ��nk� saymaya 0'dan ba�l�yor
            break;
        }

        case 4: {  //Hayvanlar� Besle
            hayvanatBahcesi.HayvanlariBesle();
            std::cout << "Hayvanlar beslendi!" << std::endl;
            break;
        }
        case 5: {  //Rapor Olu�tur
            hayvanatBahcesi.RaporOlustur();
            break;
        }
        case 6: {  //Kullan�c� ��k�� tu�una basana kadar progaram �al��maya devam eder
            std::cout << "Programdan ��k�l�yor..." << std::endl;
            return 0;
        }
        default: {  //Ge�ersiz bir de�er girdi�i zaman ekrana bas�lacak uyar�
            std::cout << "Ge�ersiz se�im! L�tfen ge�erli bir se�im yap�n." << std::endl;
            break;
        }
        }
    }
}
