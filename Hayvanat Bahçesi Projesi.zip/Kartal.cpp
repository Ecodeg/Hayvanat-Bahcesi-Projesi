/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#include "Kartal.h"
#include <iostream>

Kartal::Kartal(const std::string& ad, int yas)
    : Hayvan(ad, "Kartal", yas) {}

void Kartal::Beslen() {
    std::cout << " kartal, etle besleniyor." << std::endl;
}
