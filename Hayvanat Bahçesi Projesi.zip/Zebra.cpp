/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#include "Zebra.h"
#include <iostream>

Zebra::Zebra(const std::string& ad, int yas)
    : Hayvan(ad, "Zebra", yas) {}

void Zebra::Beslen() {
    std::cout << " zebra, otla besleniyor." << std::endl;
}
