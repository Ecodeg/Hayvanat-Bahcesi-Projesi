/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#ifndef ASLAN_H
#define ASLAN_H

#include "Hayvan.h"

class Aslan : public Hayvan {
public:
    Aslan(const std::string& ad, int yas);
    void Beslen() override;
};

#endif
