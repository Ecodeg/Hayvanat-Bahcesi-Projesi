/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#ifndef HAYVAN_H
#define HAYVAN_H

#include <string>

class Hayvan {
public:
    std::string ad;
    std::string tur;
    int yas;


    Hayvan(const std::string& ad, const std::string& tur, int yas);
    void Goster();
    void Duzenle();
    virtual void Beslen() = 0; // Saf sanal (pure virtual) fonksiyon
};

#endif
