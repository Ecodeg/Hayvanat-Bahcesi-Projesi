/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#ifndef HAYVANATBAHCESI_H
#define HAYVANATBAHCESI_H

#include "Hayvan.h"
#include <vector>

class HayvanatBahcesi {
private:
    std::vector<Hayvan*> hayvanlar;

public:
    void HayvanEkle(Hayvan* hayvan);
    void HayvanlariGoster();
    void HayvanDuzenle(int index);
    void HayvanlariBesle();
    void RaporOlustur();
};

#endif
