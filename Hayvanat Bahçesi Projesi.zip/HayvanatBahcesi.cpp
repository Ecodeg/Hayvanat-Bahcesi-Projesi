/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#include "HayvanatBahcesi.h"
#include <algorithm>
#include <iostream>

void HayvanatBahcesi::HayvanEkle(Hayvan* hayvan) {
    hayvanlar.push_back(hayvan);
}

void HayvanatBahcesi::HayvanlariGoster() {
    // Hayvanlar� t�r�ne ve ya��na g�re k���kten b�y��e s�rala
    std::sort(hayvanlar.begin(), hayvanlar.end(), [](Hayvan* h1, Hayvan* h2) {
        if (h1->tur == h2->tur)
            return h1->yas < h2->yas;
        return h1->tur < h2->tur;
        });

    // Hayvanlar� g�ster
    std::cout << "-----Hayvanlar-----" << std::endl;
    for (const auto& hayvan : hayvanlar) {
        hayvan->Goster();
        std::cout << "----------" << std::endl;
    }
}

void HayvanatBahcesi::HayvanDuzenle(int index) {
    if (index >= 0 && index < hayvanlar.size()) {
        hayvanlar[index]->Duzenle();
    }
    else {
        std::cout << "Ge�ersiz hayvan indeksi!" << std::endl;
    }
}

void HayvanatBahcesi::HayvanlariBesle() {
    for (const auto& hayvan : hayvanlar) {
        std::cout << hayvan->ad;
            hayvan->Beslen();
    }
}

void HayvanatBahcesi::RaporOlustur() {
    std::cout << "-----Hayvanat Bah�esi Raporu-----" << std::endl;

    // Harmonik ve aritmetik ortalama hesaplamas� i�in toplam ya� ve hayvan say�s� tutulacak de�i�kenler
    int toplamYas = 0;
    int hayvanSayisi = 0;

    // Her bir t�r i�in ayr� ayr� ya�lar� toplama ve hayvan say�s�n� g�ncelleme
    int aslanYasToplam = 0;
    int aslanSayisi = 0;
    int zebraYasToplam = 0;
    int zebraSayisi = 0;
    int kartalYasToplam = 0;
    int kartalSayisi = 0;

    // Hayvanlar� t�r�ne g�re gezerek ya�lar� topla ve hayvan say�s�n� g�ncelle
    for (const auto& hayvan : hayvanlar) {
        if (hayvan->tur == "Aslan") {
            aslanYasToplam += hayvan->yas;
            aslanSayisi++;
        }
        else if (hayvan->tur == "Zebra") {
            zebraYasToplam += hayvan->yas;
            zebraSayisi++;
        }
        else if (hayvan->tur == "Kartal") {
            kartalYasToplam += hayvan->yas;
            kartalSayisi++;
        }

        toplamYas += hayvan->yas;
        hayvanSayisi++;
    }

    // Harmonik ortalama hesaplamas�
    double aslanHarmonikOrtalama = (aslanSayisi>0)?(double)aslanSayisi / aslanYasToplam:0;
    double zebraHarmonikOrtalama = (zebraSayisi > 0) ? (double)zebraSayisi / zebraYasToplam:0;
    double kartalHarmonikOrtalama = (kartalSayisi > 0) ? (double)kartalSayisi / kartalYasToplam:0;
    double toplamHarmonikOrtalama = (hayvanSayisi > 0) ? (double)hayvanSayisi / toplamYas:0;

    // Aritmetik ortalama hesaplamas�
    double aslanAritmetikOrtalama = (aslanSayisi > 0) ? (double)aslanYasToplam / aslanSayisi:0;
    double zebraAritmetikOrtalama = (zebraSayisi > 0) ? (double)zebraYasToplam / zebraSayisi:0;
    double kartalAritmetikOrtalama = (kartalSayisi > 0) ? (double)kartalYasToplam / kartalSayisi:0;
    double toplamAritmetikOrtalama = (hayvanSayisi > 0) ? (double)toplamYas / hayvanSayisi:0;

    // Raporu yazd�r
    std::cout << "Aslanlar i�in Harmonik Ortalama: " << aslanHarmonikOrtalama << std::endl;
    std::cout << "Zebralar i�in Harmonik Ortalama: " << zebraHarmonikOrtalama << std::endl;
    std::cout << "Kartallar i�in Harmonik Ortalama: " << kartalHarmonikOrtalama << std::endl;
    std::cout << "T�m hayvanlar i�in Harmonik Ortalama: " << toplamHarmonikOrtalama << std::endl;
    std::cout << "Aslanlar i�in Aritmetik Ortalama: " << aslanAritmetikOrtalama << std::endl;
    std::cout << "Zebralar i�in Aritmetik Ortalama: " << zebraAritmetikOrtalama << std::endl;
    std::cout << "Kartallar i�in Aritmetik Ortalama: " << kartalAritmetikOrtalama << std::endl;
    std::cout << "T�m hayvanlar i�in Aritmetik Ortalama: " << toplamAritmetikOrtalama << std::endl;
}
