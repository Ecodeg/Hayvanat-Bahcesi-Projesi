/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#include "Aslan.h"
#include <iostream>

Aslan::Aslan(const std::string& ad, int yas)
    : Hayvan(ad, "Aslan", yas) {}

void Aslan::Beslen() {
    std::cout << " aslan, etle besleniyor." << std::endl;
}
