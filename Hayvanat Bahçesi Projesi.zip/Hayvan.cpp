/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#include "Hayvan.h"
#include <iostream>

Hayvan::Hayvan(const std::string& ad, const std::string& tur, int yas)
    : ad(ad), tur(tur), yas(yas) {}

void Hayvan::Goster() {
   
    std::cout << "Ad: " << ad << std::endl;
    std::cout << "T�r: " << tur << std::endl;
    std::cout << "Ya�: " << yas << std::endl;
}

void Hayvan::Duzenle() {
    std::cout << "Yeni ad: ";
    std::cin >> ad;
    std::cout << "Yeni t�r: ";
    std::cin >> tur;
    std::cout << "Yeni ya�: ";
    std::cin >> yas;
}
