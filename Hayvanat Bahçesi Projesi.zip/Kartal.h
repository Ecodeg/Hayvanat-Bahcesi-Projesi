/*
Ebrar G�M��
210709042
Computer Engineering
Object Oriented Programming  MUH022
Spring 2023
Project 1
Do�. Dr. Ferhat BOZKURT
*/


#ifndef KARTAL_H
#define KARTAL_H

#include "Hayvan.h"

class Kartal : public Hayvan {
public:
    Kartal(const std::string& ad, int yas);
    void Beslen() override;
};

#endif
